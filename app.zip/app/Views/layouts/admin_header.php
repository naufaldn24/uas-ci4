<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?= isset($title) ? $title : 'Dashboard Admin' ?></title>

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet" />

    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8f9fa;
        }

        /* Sidebar */
        #sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: #0d6efd;
            color: white;
            padding-top: 60px;
            transition: all 0.3s ease;
            overflow-y: auto;
            z-index: 1030;
        }

        #sidebar .nav-link {
            color: #e9ecef;
            font-weight: 600;
        }

        #sidebar .nav-link.active,
        #sidebar .nav-link:hover {
            background-color: #0b5ed7;
            color: white;
            border-radius: 0.375rem;
        }

        /* Content */
        #content {
  margin-left: 250px;
  padding: 2rem;
  transition: margin-left 0.3s ease;
  min-height: 100vh;
  background-color: #f8f9fa;
  box-sizing: border-box; /* Pastikan padding gak ngelebihin */
}


        /* Navbar */
        nav.navbar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1040;
            background-color: #fff;
            border-bottom: 1px solid #dee2e6;
            padding-left: 1rem;
            padding-right: 1rem;
            height: 56px;
            display: flex;
            align-items: center;
        }

        #sidebarToggle {
            background: none;
            border: none;
            font-size: 1.5rem;
            color: #0d6efd;
            cursor: pointer;
        }

        /* Responsive sidebar collapse */
        @media (max-width: 768px) {
            #sidebar {
                left: -250px;
            }

            #sidebar.active {
                left: 0;
            }

            #content {
                margin-left: 0;
                padding: 1rem;
            }
        }
    </style>
</head>

<body>

    <nav class="navbar shadow-sm">
        <button id="sidebarToggle" aria-label="Toggle Sidebar">&#9776;</button>
        <span class="ms-3 fw-semibold fs-5">Admin Dashboard</span>
    </nav>

    <div id="sidebar" class="">
        <nav class="nav flex-column px-3">
            <a href="/admin/dashboard"
                class="nav-link <?= uri_string() == 'admin/dashboard' ? 'active' : '' ?>">Dashboard</a>
            <a href="/admin/contacts" class="nav-link <?= uri_string() == 'admin/contacts' ? 'active' : '' ?>">Pesan</a>
            <a href="/admin/logout" class="nav-link">Logout</a>
        </nav>
    </div>

    <div id="content">
<?= $this->include('layouts/header') ?>

<!-- Hero Section -->
<section class="hero bg-dark text-white text-center py-5"
    style="background: url('/images/hero.jpg') center/cover no-repeat;">
    <div class="container py-5">
        <h1 class="display-3 fw-bold">Solusi Digital Untuk Masa Depan</h1>
        <p class="lead">Kami bantu bisnis Anda tumbuh dengan teknologi.</p>
        <a href="/contact" class="btn btn-primary btn-lg mt-3">Hubungi Kami</a>
    </div>
</section>

<!-- Services Section -->
<div class="container py-5">
    <h2 class="text-center mb-4">Layanan Kami</h2>
    <div class="row text-center">
        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Pembuatan Website</h5>
                    <p class="card-text">Website profesional, responsif & SEO-friendly sesuai kebutuhan bisnis Anda.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Aplikasi Web</h5>
                    <p class="card-text">Aplikasi berbasis web yang cepat, aman & mudah digunakan.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Konsultasi IT</h5>
                    <p class="card-text">Bantuan teknis & strategi IT untuk mendukung pertumbuhan digital Anda.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->include('layouts/footer') ?>
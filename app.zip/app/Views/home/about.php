<?= $this->include('layouts/header') ?>

<div class="container py-5">
    <h1 class="mb-4 text-center">Tentang Kami</h1>

    <p class="lead text-center">
        Kami adalah perusahaan yang bergerak di bidang teknologi digital, menyediakan solusi inovatif dan terpercaya
        untuk kebutuhan bisnis Anda.
    </p>

    <div class="row mt-5">
        <div class="col-md-6">
            <h4>Visi</h4>
            <p>
                Menjadi mitra utama dalam transformasi digital yang mendorong pertumbuhan dan efisiensi untuk bisnis di
                seluruh Indonesia.
            </p>
        </div>
        <div class="col-md-6">
            <h4>Misi</h4>
            <ul>
                <li>Menyediakan layanan berkualitas tinggi berbasis teknologi.</li>
                <li>Memberikan solusi yang disesuaikan dengan kebutuhan klien.</li>
                <li>Menjaga kepercayaan dan kepuasan pelanggan sebagai prioritas.</li>
            </ul>
        </div>
    </div>

    <div class="mt-5 text-center">
        <a href="/services" class="btn btn-outline-primary">Lihat Layanan Kami</a>
    </div>
</div>

<?= $this->include('layouts/footer') ?>
<?= $this->include('layouts/header') ?>

<div class="container py-5">
    <h1 class="text-center mb-4">Layanan Kami</h1>

    <div class="row text-center">
        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Pembuatan Website</h5>
                    <p class="card-text">
                        Kami membuat website profesional, responsif, dan SEO-friendly sesuai kebutuhan Anda.
                    </p>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Pengembangan Aplikasi</h5>
                    <p class="card-text">
                        Bangun aplikasi web yang cepat, aman, dan skalabel dengan teknologi terkini.
                    </p>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Digital Marketing</h5>
                    <p class="card-text">
                        Tingkatkan visibilitas dan konversi bisnis Anda lewat strategi pemasaran digital yang tepat.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <div class="text-center mt-4">
        <a href="/contact" class="btn btn-primary">Konsultasi Sekarang</a>
    </div>
</div>

<?= $this->include('layouts/footer') ?>
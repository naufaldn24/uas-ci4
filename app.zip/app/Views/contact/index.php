<?= $this->include('layouts/header') ?>

<div class="container py-5">
  <h1 class="text-center mb-4">Hubungi Kami</h1>

  <!-- Flashdata sukses -->
  <?php if (session()->getFlashdata('success')): ?>
    <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
  <?php endif; ?>

  <!-- Flashdata error -->
  <?php if (session()->getFlashdata('error')): ?>
    <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
  <?php endif; ?>

  <!-- Validasi error -->
  <?php if (isset($validation)): ?>
    <div class="alert alert-danger"><?= $validation->listErrors() ?></div>
  <?php endif; ?>

  <form method="post" action="/contact">
    <div class="mb-3">
      <label class="form-label">Nama</label>
      <input type="text" name="name" class="form-control" value="<?= old('name') ?>" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Email</label>
      <input type="email" name="email" class="form-control" value="<?= old('email') ?>" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Pesan</label>
      <textarea name="message" rows="5" class="form-control" required><?= old('message') ?></textarea>
    </div>

    <button type="submit" class="btn btn-primary">Kirim</button>
  </form>
</div>

<?= $this->include('layouts/footer') ?>